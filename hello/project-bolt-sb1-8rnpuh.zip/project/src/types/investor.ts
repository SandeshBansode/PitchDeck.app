export interface Investor {
  id: number;
  name: string;
  type: string;
  focus: string;
  location: string;
  investmentRange: string;
  logo: string;
}