export interface Startup {
  id: number;
  name: string;
  description: string;
  industry: string;
  fundingStage: string;
  location: string;
  logo: string;
}