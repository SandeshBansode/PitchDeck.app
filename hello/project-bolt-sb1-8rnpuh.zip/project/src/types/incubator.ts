export interface Incubator {
  id: number;
  name: string;
  focus: string;
  duration: string;
  location: string;
  benefits: string;
  logo: string;
}