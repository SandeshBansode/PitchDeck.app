import { Investor } from '../types/investor';

export const investors: Investor[] = [
  {
    id: 1,
    name: 'Venture Capital Partners',
    type: 'Venture Capital',
    focus: 'Technology, SaaS',
    location: 'New York, NY',
    investmentRange: '$1M - $5M',
    logo: 'https://images.unsplash.com/photo-1560179707-f14e90ef3623?w=128&h=128&fit=crop',
  },
  // Original entries...
  {
    id: 4,
    name: 'Digital Horizons VC',
    type: 'Venture Capital',
    focus: 'Digital Transformation',
    location: 'Berlin, Germany',
    investmentRange: '$2M - $10M',
    logo: 'https://images.unsplash.com/photo-1579547944212-c4f4961a8dd8?w=128&h=128&fit=crop',
  },
  {
    id: 5,
    name: 'Green Future Fund',
    type: 'Impact Investment',
    focus: 'Sustainability, CleanTech',
    location: 'Oslo, Norway',
    investmentRange: '$500K - $3M',
    logo: 'https://images.unsplash.com/photo-1564419320461-6870880221ad?w=128&h=128&fit=crop',
  },
  // Adding more entries...
  {
    id: 20,
    name: 'Future Spark Capital',
    type: 'Venture Capital',
    focus: 'DeepTech, AI',
    location: 'Toronto, Canada',
    investmentRange: '$1M - $7M',
    logo: 'https://images.unsplash.com/photo-1557804506-669a67965ba0?w=128&h=128&fit=crop',
  },
];