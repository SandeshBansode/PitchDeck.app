import { Startup } from '../types/startup';

export const startups: Startup[] = [
  {
    id: 1,
    name: 'TechVision AI',
    description: 'AI-powered business analytics platform',
    industry: 'Artificial Intelligence',
    fundingStage: 'Series A',
    location: 'San Francisco, CA',
    logo: 'https://images.unsplash.com/photo-1551288049-bebda4e38f71?w=128&h=128&fit=crop',
  },
  // Original entries...
  {
    id: 4,
    name: 'CyberShield',
    description: 'Next-gen cybersecurity solutions',
    industry: 'Cybersecurity',
    fundingStage: 'Series B',
    location: 'Tel Aviv, Israel',
    logo: 'https://images.unsplash.com/photo-1563986768609-322da13575f3?w=128&h=128&fit=crop',
  },
  {
    id: 5,
    name: 'FinFlow',
    description: 'Decentralized finance platform',
    industry: 'FinTech',
    fundingStage: 'Seed',
    location: 'Singapore',
    logo: 'https://images.unsplash.com/photo-1559526324-593bc073d938?w=128&h=128&fit=crop',
  },
  // Adding more entries...
  {
    id: 20,
    name: 'EcoHarvest',
    description: 'Smart farming solutions',
    industry: 'AgTech',
    fundingStage: 'Series A',
    location: 'Amsterdam, Netherlands',
    logo: 'https://images.unsplash.com/photo-1560493676-04071c5f467b?w=128&h=128&fit=crop',
  },
];