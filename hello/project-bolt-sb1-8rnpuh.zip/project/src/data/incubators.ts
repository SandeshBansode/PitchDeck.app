import { Incubator } from '../types/incubator';

export const incubators: Incubator[] = [
  {
    id: 1,
    name: 'TechStars',
    focus: 'Technology Startups',
    duration: '3 months',
    location: 'Boulder, CO',
    benefits: 'Mentorship, Funding, Network',
    logo: 'https://images.unsplash.com/photo-1497366216548-37526070297c?w=128&h=128&fit=crop',
  },
  // Original entries...
  {
    id: 4,
    name: 'Startup Factory',
    focus: 'B2B SaaS',
    duration: '4 months',
    location: 'Paris, France',
    benefits: 'Workspace, Mentoring, Funding',
    logo: 'https://images.unsplash.com/photo-1504384308090-c894fdcc538d?w=128&h=128&fit=crop',
  },
  {
    id: 5,
    name: 'FinTech Hub',
    focus: 'Financial Technology',
    duration: '6 months',
    location: 'Hong Kong',
    benefits: 'Industry Connections, Funding',
    logo: 'https://images.unsplash.com/photo-1563986768494-4dee9056a72c?w=128&h=128&fit=crop',
  },
  // Adding more entries...
  {
    id: 20,
    name: 'BioTech Accelerator',
    focus: 'Healthcare & Biotech',
    duration: '12 months',
    location: 'Basel, Switzerland',
    benefits: 'Lab Space, Research Grants',
    logo: 'https://images.unsplash.com/photo-1532187863486-abf9dbad1b69?w=128&h=128&fit=crop',
  },
];