import React, { ReactNode } from 'react';
import { Link, useLocation } from 'react-router-dom';

interface NavLinkProps {
  icon: ReactNode;
  href: string;
  label: string;
}

export function NavLink({ icon, href, label }: NavLinkProps) {
  const location = useLocation();
  const isActive = location.pathname === href;

  return (
    <Link
      to={href}
      className={`flex items-center px-3 py-2 rounded-md text-sm font-medium transition-colors ${
        isActive ? 'bg-indigo-500' : 'hover:bg-indigo-500'
      }`}
    >
      <span className="mr-2">{icon}</span>
      {label}
    </Link>
  );
}