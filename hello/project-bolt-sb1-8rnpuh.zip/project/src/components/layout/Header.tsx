import React from 'react';
import { Rocket, Users, Lightbulb, BookOpen } from 'lucide-react';
import { NavLink } from './NavLink';

export function Header() {
  return (
    <header className="bg-indigo-600 text-white">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="flex items-center justify-between h-16">
          <div className="flex items-center">
            <Rocket className="h-8 w-8" />
            <span className="ml-2 text-xl font-bold">PitchDeck</span>
          </div>
          <nav className="flex space-x-4">
            <NavLink icon={<Rocket />} href="/startups" label="Startups" />
            <NavLink icon={<Users />} href="/investors" label="Investors" />
            <NavLink icon={<Lightbulb />} href="/incubators" label="Incubators" />
            <NavLink icon={<BookOpen />} href="/courses" label="Courses" />
          </nav>
        </div>
      </div>
    </header>
  );
}